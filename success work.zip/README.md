## Follow these steps to clone and run this project in your computer


### 1. copy the link below to your terminal
```git clone https://github.com/Sugarcothe/marvelo.git```

### 2. Navigate to the cloned project
```cd marvelo```

### 3. Install packages
```npm install```

### 4. Run the site
``npm run dev``

### 5. View the site on browser
copy ```http://http://localhost:5173/``` to the browseR


